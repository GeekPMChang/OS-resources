#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <wait.h>
#include <time.h>
#include <fcntl.h>
pid_t parentpid, childpid;
typedef void (*sighandler_t) (int);

//信号处理函数
void sigcat(){
    if(getpid() == parentpid)
        kill(childpid, SIGINT);    
}

//获取输入的信息
void getstr(char *str){
    char ch;
    int i = 0;
    while(scanf("%c", &ch) != EOF){
        if(ch != '\0' && ch != '\n')
            str[i++] = ch;
        else
            break;
    }
}

//解析命令
int parse(char *line, char **args){
    memset(args, 0, sizeof(char*)*64);
    int cnt = 0;//记录切割后的字符串的数目
    char *str = line;//保存输入的命令
    char *tmp = NULL;//保存每次分割后的剩余字符串
    
    //对输入命令字符串按照“ ”进行切割
    while((args[cnt] = strtok_r(str, " ", &tmp)) != NULL){
        cnt++;
        str = NULL;
    }

    return cnt;
}

//执行无管道的指令
void exec(char *cmd){
    size_t pid;
    int status;
    char *in = NULL, *out = NULL;//重定向的输入和输出文件的名称
    int rein = 0, reout = 0;//重定向输入和输出的个数
    
    char temp[256];
    strcpy(temp, cmd);
	char *args[256];
    int argc = parse(temp, args);//分割后得到的字符串的数目
    int eidx = argc;//对于重定向操作的终止下标
    
    for(int i = 0; i < argc; i++){
        //确定重定向符“>”和“<”的数目
        if(!strcmp(args[i], "<")){
            if(i + 1 >= argc){
                printf("File name dose not exist.\n");
                exit(1);
            }
            else
                in = args[++i];//存储文件名
            
            rein++;
            //对于重定向操作,需要执行的操作应该只到倒数第二个字符
            if(eidx == argc) eidx = i - 1;
        }

        if(!strcmp(args[i], ">")){
            if(i + 1 >= argc){
                printf("File name dose not exist.\n");
                exit(1);
            }
            else
                out = args[++i];//存储文件名
            
            reout++;
            //对于重定向操作,需要执行的操作应该只到倒数第二个字符
            if(eidx == argc) eidx = i - 1;
        }
    }
    
    //重定向输入输出的数目大于1的情况
    if(rein > 1){
        printf("Too many redirection input files\n");
    }
    else if(reout > 1){
        printf("Too many redirection output files.\n");
    }
    
    //重定向输入的目标文件不存在
    else if(rein == 1){
        FILE *fp = fopen(in, "r");
        if(fp == NULL)
            printf("The input file dose not exist.\n");
        fclose(fp);
    }
    
    //处理指令
    childpid = fork();
    if(childpid < 0){
        printf("Create Process fail!\n");
        exit(1);
    }
    else if(childpid == 0){
        //有重定向输入
        if(rein == 1){
            close(0);
            if(open(in, O_RDONLY) != 0){
                fprintf(stderr, "testsh: open != 0\n");
                exit(-1);
		    }

        }
        
        //有重定向输出
        if(reout == 1){
            close(1);
            if(open(out, O_CREAT|O_WRONLY|O_TRUNC, 0644) != 1){
                fprintf(stderr, "testsh: open != 1\n");
                exit(-1);
		    }
        }
        
        //无重定向操作
        char *tmp[256];
        for(int i = 0; i < eidx; i++)
            tmp[i] = args[i];
        tmp[eidx] = NULL;
        
        if(execvp(tmp[0], tmp) < 0)
            printf("ERROR: invalid command.\n");
        exit(1);
    }
    else{
        waitpid(childpid, &status, 0);
    }
}

//处理包含管道的指令
void dealpipe(char *cmd){
    size_t pid;
    char *now;//存放多级管道指令中当前需要执行的指令的字符串
    char *next = NULL;//存储分割后的剩余指令字符串
    char *args[256];
    
    //无管道指令，直接执行
    if(strstr(cmd, "|") == NULL){
        exec(cmd);
        return;
    }
    
    //有管道指令,对指令开始进行分割
    now = strtok_r(cmd, "|", &next);
    if(*next == 0){
        printf("There are no follow-up commands after |.\n");
        exit(1);
    }
    
    int tube[2];
    if(pipe(tube) < 0){
        printf("create pipe failed.\n");
    }
    
    childpid = fork();
    if(childpid < 0){
        printf("create fork failed.\n");
        exit(1);
    }
    else if(childpid == 0){
        close(tube[0]);
        dup2(tube[1], 1);//将标准输出重定向到管道的输出
        exec(now);
    }
    else{
        int status;
        waitpid(childpid, &status, 0);
        
        close(tube[1]);
        dup2(tube[0], 0);//将标准输入重定向到管道的输入
        
        dealpipe(next);//处理下一级指令
        
        close(tube[0]);
    }
}

int main(){
    parentpid = getpid();
    signal(SIGINT, (sighandler_t)sigcat);
    char line[256];
    char *arglist[256];
    
    while(1){
        memset(line, 0, sizeof(line));
        getstr(line);//获取输入的命令
        fflush(stdin);

        if(*line == '\n') continue;
        if(*line == '\0') exit(1);

        char temp[256];
        strcpy(temp, line);
        parse(temp, arglist);//对输入的指令进行解析
        
        int stdinput = dup(0);//备份标准输入输出标识符
        int stdoutput = dup(1);
        
        dealpipe(line);
        
        dup2(stdinput, 0);  //恢复标准输入输出标识符
        dup2(stdoutput, 1);
    }
    return 0;
}

